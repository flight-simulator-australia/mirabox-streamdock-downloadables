Copy com.ctytler.dcs.sdPlugin into C:\Users\用户名\AppData\Roaming\HotSpot\StreamDock\plugins

DCS end script: copy into C:\Users\用户名\Saved Games\DCS\Scripts,
For Export.lua, may need your manually merge the script.

Restart streamdock, making sure if DCS interface presents

Launch DCS game, open any mission.

Drag a plugiu into your button area, click "ID Lookup", assgin DCS game path for the first time.

Click DCS Comms, Refresh and confirm if you got data.

More details, please refer to video turorial.

Enjoy!